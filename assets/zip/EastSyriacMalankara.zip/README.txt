Font Release v1.0
Developed by Binu George (May 15, 2025) with input from Josekutty Abraham (Hendo Academy).

Hendo Academy promotes Syriac language/culture: hendoacademy.org

Contributions welcome: gbinu42@gmail.com